namespace Producto.Models
{
    public class ImagenProductoDto
    {
        
        public string Url { get; set; }
        public int ProductoId { get; set; }
    }
}
