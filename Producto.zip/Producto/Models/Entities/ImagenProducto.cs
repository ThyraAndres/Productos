using System;
namespace Producto.Models

{
    public class ImagenProducto
    {
        public int Id { get; set; }
        public string? Url { get; set; }

        // Relación con Producto (muchos a uno)
        public int ProductoId { get; set; }  // Referencia al Producto al que pertenece la imagen
        public virtual Productos? Producto { get; set; }  // La imagen pertenece a un solo producto
    }
}