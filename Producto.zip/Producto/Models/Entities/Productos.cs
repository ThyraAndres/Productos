using System.Security.Cryptography.X509Certificates;
using System;
using System.Collections.Generic;

namespace Producto.Models
{
    public class Productos
    {
        public int Id { get; set; }
        public string? Nombre { get; set; }
        public string? Descripcion { get; set; }
        public decimal Precio { get; set; }
        public DateTime FechaCreacion { get; set; }
        public bool Estado { get; set; }

        // Relación con ImagenProducto (uno a muchos)
        public virtual ICollection<ImagenProducto>? Imagenes { get; set; }  // Un producto puede tener varias imágenes
    }
}
