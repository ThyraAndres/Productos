using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;

public class GlobalExceptionFilter : IExceptionFilter
{
    public void OnException(ExceptionContext context)
    {
        var exception = context.Exception;
        var response = new Dictionary<string, string>
        {
            { "Message", "An unexpected error occurred." },
            { "Timestamp", DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss") }
        };

        if (exception is InvalidOperationException)
        {
            context.Result = new JsonResult(response)
            {
                StatusCode = 400
            };
        }
        else
        {
            context.Result = new JsonResult(response)
            {
                StatusCode = 500
            };
        }

        context.ExceptionHandled = true;
    }
}
