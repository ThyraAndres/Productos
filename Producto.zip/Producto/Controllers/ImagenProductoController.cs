using Microsoft.AspNetCore.Mvc;
using Producto.Models;
using Producto.Services;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Producto.Controllers
{
    [ApiController]
    [Route("api/imagenProducto")]
    public class ImagenesProductosController : ControllerBase
    {
        private readonly IImagenProductoService _imagenProductoService;

        public ImagenesProductosController(IImagenProductoService imagenProductoService)
        {
            _imagenProductoService = imagenProductoService;
        }

        // POST: api/imagenProducto
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] ImagenProductoDto imagenProductoDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var createdImagen = await _imagenProductoService.CreateAsync(imagenProductoDto);
                return CreatedAtAction(nameof(GetByProductoId), new { Id = createdImagen.Id }, createdImagen);
            }
            catch (ApiException ex)
            {
                return StatusCode(ex.StatusCode, new { message = ex.Message, details = ex.Details });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An unexpected error occurred", details = ex.Message });
            }
        }

        // GET: api/imagenProducto/{Id}
        [HttpGet("{Id}")]
        public async Task<IActionResult> GetByProductoId(int Id)
        {
            var imagenes = await _imagenProductoService.GetByProductoIdAsync(Id);

            if (imagenes == null || !imagenes.Any())
            {
                return NotFound($"No images found for product {Id}");
            }

            return Ok(imagenes);  // Aquí ya estamos retornando las imágenes asociadas al producto
        }

        // PUT: api/imagenProducto/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] ImagenProductoDto imagenProductoDto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var updatedImagen = await _imagenProductoService.UpdateAsync(id, imagenProductoDto);

            if (updatedImagen == null)
            {
                return NotFound($"Image with Id {id} not found.");
            }

            return Ok(updatedImagen);
        }

        // DELETE: api/imagenProducto/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var result = await _imagenProductoService.DeleteAsync(id);

            if (!result)
            {
                return NotFound($"Image with Id {id} not found.");
            }

            return NoContent();
        }
    }
}
