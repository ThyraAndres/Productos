using Microsoft.AspNetCore.Mvc;
using Producto.Models;
using Producto.Services;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Producto.Controllers
{
    [Route("api/productos")]
    [ApiController]
    public class ProductosController : ControllerBase
    {
        private readonly IProductosService _productoService;

        // Inyección de dependencias
        public ProductosController(IProductosService productoService)
        {
            _productoService = productoService;
        }

        // GET: api/productos
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ProductoDto>>> GetProductos()
        {
            var productos = await _productoService.GetAllProductosAsync();
            return Ok(productos); 
        }

        // GET: api/productos/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ProductoDto>> GetProducto(int id)
        {
            var producto = await _productoService.GetProductoByIdAsync(id);
            if (producto == null)
            {
                return NotFound();
            }
            return Ok(producto);  
        }

        // POST: api/productos
        [HttpPost]
        public async Task<ActionResult<ProductoDto>> PostProducto(ProductoDto productoDto)
        {
            try
            {
                var productoCreado = await _productoService.AddProductoAsync(productoDto);
                return CreatedAtAction(nameof(GetProducto), new { id = productoCreado.Id }, productoCreado);  // Devuelve ProductoDto
            }
            catch (ApiException ex)
            {
                return StatusCode(ex.StatusCode, new { message = ex.Message, details = ex.Details });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An unexpected error occurred", details = ex.Message });
            }
        }

        // PUT: api/productos/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutProducto(int id, ProductoDto productoDto)
        {
            if (id != productoDto.Id)
            {
                return BadRequest();
            }
            Console.WriteLine($"Solicitud recibida para actualizar el producto con ID: {id}");
            var productoActualizado = await _productoService.UpdateProductoAsync(id, productoDto);
            if (productoActualizado == null)
            {
                return NotFound();
            }
            return NoContent();
        }

        // DELETE: api/productos/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProducto(int id)
        {
            var exito = await _productoService.DeleteProductoAsync(id);
            if (!exito)
            {
                return NotFound();
            }
            return NoContent();
        }
    }
}
