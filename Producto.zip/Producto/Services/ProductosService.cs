using AutoMapper;
using Producto.Models;
using Producto.Repositories;
using Producto.Services;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Producto.Services
{
    public class ProductoService : IProductosService
    {
        private readonly IProductoRepository _productoRepository;
        private readonly IMapper _mapper;

        // Inyección de dependencias
        public ProductoService(IProductoRepository productoRepository, IMapper mapper)
        {
            _productoRepository = productoRepository;
            _mapper = mapper;
        }

        // Obtener todos los productos
        public async Task<IEnumerable<ProductoDto>> GetAllProductosAsync()
        {
            var productos = await _productoRepository.GetAllProductosAsync();
            return _mapper.Map<IEnumerable<ProductoDto>>(productos);
        }

        // Obtener un producto por ID
        public async Task<ProductoDto> GetProductoByIdAsync(int id)
        {
            var producto = await _productoRepository.GetProductoByIdAsync(id);
            return _mapper.Map<ProductoDto>(producto);
        }

        // Agregar un nuevo producto
        public async Task<ProductoDto> AddProductoAsync(ProductoDto productoDto)
        {
            var producto = _mapper.Map<Productos>(productoDto);
            await _productoRepository.AddProductoAsync(producto);
            return _mapper.Map<ProductoDto>(producto);
        }

        // Actualizar un producto existente
        public async Task<ProductoDto> UpdateProductoAsync(int id, ProductoDto productoDto)
        {
            var producto = await _productoRepository.GetProductoByIdAsync(id);
            if (producto == null)
                throw new ApiException(404, "Producto no encontrada.");


            _mapper.Map(productoDto, producto);
            await _productoRepository.UpdateProductoAsync(producto);

            return _mapper.Map<ProductoDto>(producto);
        }

        // Eliminar un producto
        public async Task<bool> DeleteProductoAsync(int id)
        {
            var producto = await _productoRepository.GetProductoByIdAsync(id);
            if (producto == null)
                throw new ApiException(404, "Producto no encontrado.");


            await _productoRepository.DeleteProductoAsync(id);
            return true;
        }
    }
}
