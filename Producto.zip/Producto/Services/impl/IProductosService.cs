using Producto.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Producto.Services
{
    public interface IProductosService
    {
        // Obtener todos los productos como DTOs
        Task<IEnumerable<ProductoDto>> GetAllProductosAsync();
        
        // Obtener un producto por su ID como DTO
        Task<ProductoDto> GetProductoByIdAsync(int id);
        
        // Agregar un nuevo producto (con un DTO)
        Task<ProductoDto> AddProductoAsync(ProductoDto productoDto);
        
        // Actualizar un producto existente (con un DTO)
        Task<ProductoDto> UpdateProductoAsync(int id, ProductoDto productoDto);
        
        // Eliminar un producto
        Task<bool> DeleteProductoAsync(int id);
    }
}
