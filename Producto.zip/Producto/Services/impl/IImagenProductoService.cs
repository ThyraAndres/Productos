using Producto.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Producto.Services
{
    public interface IImagenProductoService
    {
        Task<ImagenProducto> CreateAsync(ImagenProductoDto imagenProductoDto);
        Task<IEnumerable<ImagenProducto>> GetByProductoIdAsync(int productoId);
        Task<ImagenProducto> UpdateAsync(int id, ImagenProductoDto imagenProductoDto);
        Task<bool> DeleteAsync(int id);
    }
}