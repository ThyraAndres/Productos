using Producto.Models;
using Producto.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;

namespace Producto.Services
{
    public class ImagenProductoService : IImagenProductoService
    {
        private readonly IImagenProductoRepository _imagenProductoRepository;
        private readonly IMapper _mapper;

        public ImagenProductoService(IImagenProductoRepository imagenProductoRepository, IMapper mapper)
        {
            _imagenProductoRepository = imagenProductoRepository;
            _mapper = mapper;
        }

        public async Task<ImagenProducto> CreateAsync(ImagenProductoDto imagenProductoDto)
        {
            var imagenProducto = _mapper.Map<ImagenProducto>(imagenProductoDto);
            return await _imagenProductoRepository.CreateAsync(imagenProducto);
        }

        public async Task<IEnumerable<ImagenProducto>> GetByProductoIdAsync(int productoId)
        {
            return await _imagenProductoRepository.GetByProductoIdAsync(productoId);
        }

        public async Task<ImagenProducto> UpdateAsync(int id, ImagenProductoDto imagenProductoDto)
        {
            var imagenProducto = await _imagenProductoRepository.GetByIdAsync(id);

            if (imagenProducto == null)
                throw new ApiException(404, "Imagen no encontrada.");

            _mapper.Map(imagenProductoDto, imagenProducto);

            await _imagenProductoRepository.SaveAsync(imagenProducto);
            return imagenProducto;
        }

        public async Task<bool> DeleteAsync(int id)
        {
            var imagenProducto = await _imagenProductoRepository.GetByIdAsync(id);
            if (imagenProducto == null)
                throw new ApiException(404, "Imagen no encontrada.");

            return await _imagenProductoRepository.DeleteAsync(imagenProducto);
        }
    }
}
