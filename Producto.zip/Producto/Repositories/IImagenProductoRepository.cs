using Producto.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Producto.Repositories
{
    public interface IImagenProductoRepository
    {
        Task<ImagenProducto> CreateAsync(ImagenProducto imagenProducto);
        Task<IEnumerable<ImagenProducto>> GetByProductoIdAsync(int productoId);
        Task<ImagenProducto> GetByIdAsync(int id);  
        Task<bool> DeleteAsync(ImagenProducto imagenProducto);  
        Task SaveAsync(ImagenProducto imagenProducto);
    }
}
