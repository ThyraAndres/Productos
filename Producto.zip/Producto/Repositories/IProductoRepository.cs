using Producto.Models;


namespace Producto.Repositories
{
    public interface IProductoRepository
    {
        Task<IEnumerable<Productos>> GetAllProductosAsync();
        Task<Productos> GetProductoByIdAsync(int id);
        Task AddProductoAsync(Productos producto);
        Task UpdateProductoAsync(Productos producto);
        Task DeleteProductoAsync(int id);
    }
}
