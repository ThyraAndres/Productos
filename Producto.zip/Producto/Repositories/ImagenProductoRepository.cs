using Producto.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Producto.Repositories
{
    public class ImagenProductoRepository : IImagenProductoRepository
    {
        private readonly AppDbContext _context;

        public ImagenProductoRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<ImagenProducto> CreateAsync(ImagenProducto imagenProducto)
        {
            _context.ImagenesProductos.Add(imagenProducto);
            await _context.SaveChangesAsync();
            return imagenProducto;
        }

        public async Task<IEnumerable<ImagenProducto>> GetByProductoIdAsync(int productoId)
        {
            return await _context.ImagenesProductos
                .Where(img => img.ProductoId == productoId)
                .ToListAsync();
        }

        public async Task<ImagenProducto> GetByIdAsync(int id)
        {
            return await _context.ImagenesProductos.FindAsync(id);
        }

        public async Task<bool> DeleteAsync(ImagenProducto imagenProducto)
        {
            _context.ImagenesProductos.Remove(imagenProducto);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task SaveAsync(ImagenProducto imagenProducto)
        {
            _context.ImagenesProductos.Update(imagenProducto);
            await _context.SaveChangesAsync();
        }
    }
}
