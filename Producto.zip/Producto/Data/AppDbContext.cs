using Microsoft.EntityFrameworkCore;
using Producto.Models;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    {
    }

    public DbSet<Productos> Productos { get; set; }
    public DbSet<ImagenProducto> ImagenesProductos { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);


        // Datos iniciales
        var imagenProducto = new ImagenProducto()
        {
            Id = 1,
            Url = "https://img.freepik.com/foto-gratis/rosa-cupula-cristal-rosas-rojas-mesa_140725-10995.jpg?t=st=1742084705~exp=1742088305~hmac=0ec3ca2694200be55b13d48ebb1e6b884f17b0e8c547418ff646bc9259b0abca&w=826",
            ProductoId = 1 // Asociando la imagen al producto con ID 1

        };
        var imagenProducto2 = new ImagenProducto
        {
            Id = 2,
            Url = "https://img.freepik.com/foto-gratis/rosa-cupula-cristal-rosas-rojas-mesa_140725-10995.jpg?t=st=1742084705~exp=1742088305~hmac=0ec3ca2694200be55b13d48ebb1e6b884f17b0e8c547418ff646bc9259b0abca&w=827",
            ProductoId = 1 // Asociando la imagen al producto con ID 1
        };

        var producto1 = new Productos
        {
            Id = 1,
            Nombre = "Flor Eterna",
            Descripcion = "Es una flor que simboliza la duración",
            Precio = 30.0m,
            FechaCreacion = new DateTime(),
            Estado = true,
        };

        modelBuilder.Entity<ImagenProducto>().HasData(imagenProducto,imagenProducto2);
        modelBuilder.Entity<Productos>().HasData(producto1);
        // Configuración de la relación uno a muchos entre Producto e ImagenProducto
        modelBuilder.Entity<Productos>()
            .HasMany(p => p.Imagenes)
            .WithOne(i => i.Producto)
            .HasForeignKey(i => i.ProductoId)
            .HasConstraintName("FK_Productos_ImagenProducto");
    }
}
