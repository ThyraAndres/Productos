using Producto.Services;
using Microsoft.EntityFrameworkCore;
using Producto.Repositories;
using Producto.Mapping;
using AutoMapper;
using Microsoft.Extensions.DependencyInjection;
using System.Reflection;


var builder = WebApplication.CreateBuilder(args);

// Configurar servicios
builder.Services.AddControllersWithViews();
builder.Services.AddDbContext<AppDbContext>(
    options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("Default"))
);
// Registra el filtro global de excepciones
builder.Services.AddControllers(options =>
{
    options.Filters.Add(new GlobalExceptionFilter());
});
// Habiliatar CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowFrontend", policy =>
    {
        policy.WithOrigins("http://localhost:4200")
              .AllowAnyMethod() 
              .AllowAnyHeader(); 
    });
});
// Registrar el repositorio
builder.Services.AddScoped<IProductoRepository, ProductoRepository>();
builder.Services.AddScoped<IImagenProductoRepository, ImagenProductoRepository>();
// Registrar el servicio
builder.Services.AddScoped<IProductosService, ProductoService>();
builder.Services.AddScoped<IImagenProductoService, ImagenProductoService>();
// Otros servicios necesarios
builder.Services.AddAutoMapper(typeof(MappingProfile).Assembly);
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();

// builder.Services.AddSwaggerGen();
var app = builder.Build();

app.UseCors("AllowFrontend");
// Configuracion HTTP request
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}
if (app.Environment.IsDevelopment())
{
    app.UseCors("AllowFrontend");
}
app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
