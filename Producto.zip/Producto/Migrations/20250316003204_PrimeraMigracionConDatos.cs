﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Producto.Migrations
{
    /// <inheritdoc />
    public partial class PrimeraMigracionConDatos : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "ImagenProductos",
                columns: new[] { "Id", "Foto" },
                values: new object[] { 1, "https://img.freepik.com/foto-gratis/rosa-cupula-cristal-rosas-rojas-mesa_140725-10995.jpg?t=st=1742084705~exp=1742088305~hmac=0ec3ca2694200be55b13d48ebb1e6b884f17b0e8c547418ff646bc9259b0abca&w=826" });

            migrationBuilder.InsertData(
                table: "Productos",
                columns: new[] { "Id", "Descripcion", "Estado", "FechaCreacion", "IdImagenProducto", "Nombre", "Precio" },
                values: new object[] { 1, "Es una flor que simboliza la duración", true, new DateTime(2025, 3, 15, 20, 32, 1, 985, DateTimeKind.Local).AddTicks(4428), 1, "Flor Eterna", 30m });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Productos",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "ImagenProductos",
                keyColumn: "Id",
                keyValue: 1);
        }
    }
}
