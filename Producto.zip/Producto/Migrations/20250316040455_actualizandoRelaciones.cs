﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Producto.Migrations
{
    /// <inheritdoc />
    public partial class actualizandoRelaciones : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Productos_ImagenProducto",
                table: "Productos");

            migrationBuilder.DropTable(
                name: "ImagenProductos");

            migrationBuilder.DropIndex(
                name: "IX_Productos_IdImagenProducto",
                table: "Productos");

            migrationBuilder.DropColumn(
                name: "IdImagenProducto",
                table: "Productos");

            migrationBuilder.CreateTable(
                name: "ImagenesProductos",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Url = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ProductoId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ImagenesProductos", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Productos_ImagenProducto",
                        column: x => x.ProductoId,
                        principalTable: "Productos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "ImagenesProductos",
                columns: new[] { "Id", "ProductoId", "Url" },
                values: new object[] { 1, 1, "https://img.freepik.com/foto-gratis/rosa-cupula-cristal-rosas-rojas-mesa_140725-10995.jpg?t=st=1742084705~exp=1742088305~hmac=0ec3ca2694200be55b13d48ebb1e6b884f17b0e8c547418ff646bc9259b0abca&w=826" });

            migrationBuilder.UpdateData(
                table: "Productos",
                keyColumn: "Id",
                keyValue: 1,
                column: "FechaCreacion",
                value: new DateTime(2025, 3, 16, 4, 4, 52, 914, DateTimeKind.Utc).AddTicks(7817));

            migrationBuilder.CreateIndex(
                name: "IX_ImagenesProductos_ProductoId",
                table: "ImagenesProductos",
                column: "ProductoId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ImagenesProductos");

            migrationBuilder.AddColumn<int>(
                name: "IdImagenProducto",
                table: "Productos",
                type: "int",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "ImagenProductos",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Foto = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ImagenProductos", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "ImagenProductos",
                columns: new[] { "Id", "Foto" },
                values: new object[] { 1, "https://img.freepik.com/foto-gratis/rosa-cupula-cristal-rosas-rojas-mesa_140725-10995.jpg?t=st=1742084705~exp=1742088305~hmac=0ec3ca2694200be55b13d48ebb1e6b884f17b0e8c547418ff646bc9259b0abca&w=826" });

            migrationBuilder.UpdateData(
                table: "Productos",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "FechaCreacion", "IdImagenProducto" },
                values: new object[] { new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 1 });

            migrationBuilder.CreateIndex(
                name: "IX_Productos_IdImagenProducto",
                table: "Productos",
                column: "IdImagenProducto");

            migrationBuilder.AddForeignKey(
                name: "FK_Productos_ImagenProducto",
                table: "Productos",
                column: "IdImagenProducto",
                principalTable: "ImagenProductos",
                principalColumn: "Id");
        }
    }
}
