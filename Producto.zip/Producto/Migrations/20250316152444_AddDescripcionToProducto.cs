﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Producto.Migrations
{
    /// <inheritdoc />
    public partial class AddDescripcionToProducto : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "ImagenesProductos",
                columns: new[] { "Id", "ProductoId", "Url" },
                values: new object[] { 2, 1, "https://img.freepik.com/foto-gratis/rosa-cupula-cristal-rosas-rojas-mesa_140725-10995.jpg?t=st=1742084705~exp=1742088305~hmac=0ec3ca2694200be55b13d48ebb1e6b884f17b0e8c547418ff646bc9259b0abca&w=827" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "ImagenesProductos",
                keyColumn: "Id",
                keyValue: 2);
        }
    }
}
