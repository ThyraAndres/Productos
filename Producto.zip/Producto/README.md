Producto API
Este proyecto es una API RESTful para la gestión de productos e imágenes. Está construida usando ASP.NET Core con AutoMapper para la conversión de DTOs y entidades, y con una arquitectura en capas para una fácil escalabilidad y mantenimiento.

Requisitos
1. .NET SDK
Necesitas tener instalado el SDK de .NET 6.0 o superior. Puedes descargarlo desde aquí y seguir las instrucciones para tu sistema operativo.

2. Visual Studio Code (VSCode)
Si estás usando Visual Studio Code, asegúrate de tener instaladas las siguientes extensiones para facilitar el desarrollo en C#:

C# (oficial de Microsoft) para soporte completo de C# y ASP.NET Core.
C# Extensions para facilitar la navegación en proyectos C#.
SQL Server (mssql) para facilitar la administración de bases de datos SQL Server desde VSCode.
Puedes instalar estas extensiones directamente desde la barra lateral de extensiones en VSCode o mediante los comandos en la terminal:

bash
Copy
ext install ms-dotnettools.csharp
ext install christian-kohler.path-intellisense
ext install ms-mssql.mssql
3. .NET Framework (si es necesario)
Si estás utilizando .NET Framework 4.7.2 (para proyectos que no son .NET Core), puedes descargarlo desde aquí.

4. SQL Server y Entity Framework
Este proyecto usa Entity Framework Core con SQL Server como base de datos. Asegúrate de tener SQL Server instalado y configurado correctamente. Para usar Entity Framework Core, también debes instalar la herramienta dotnet-ef globalmente.

Instalación de dependencias
1. Clonar el repositorio
Si aún no tienes el proyecto, clónalo a tu máquina local:

bash
Copy
git clone https://github.com/tu-repositorio/producto.git
cd producto

2. Instalar las dependencias necesarias
Ejecuta el siguiente comando en la raíz del proyecto para restaurar las dependencias de NuGet:

bash
Copy
dotnet restore

3. Instalar las dependencias requeridas
Asegúrate de que las siguientes dependencias estén en tu archivo Producto.csproj o instálalas utilizando los siguientes comandos:

bash
Copy
dotnet add package AutoMapper --version 12.0.1
dotnet add package AutoMapper.Extensions.Microsoft.DependencyInjection --version 12.0.0
dotnet add package Microsoft.EntityFrameworkCore --version 6.0.0
dotnet add package Microsoft.EntityFrameworkCore.SqlServer --version 6.0.0
dotnet add package Microsoft.EntityFrameworkCore.Tools --version 6.0.0
dotnet add package Swashbuckle.AspNetCore --version 6.2.3
dotnet add package FluentValidation.AspNetCore --version 10.3.6
dotnet add package xunit
dotnet add package xunit.runner.visualstudio
dotnet add package Moq
dotnet add package Microsoft.EntityFrameworkCore.InMemory
dotnet add package Microsoft.Extensions.DependencyInjection
ng build --configuration=production

4. Instalar la herramienta dotnet-ef
Para poder generar y aplicar migraciones de la base de datos, necesitas instalar la herramienta dotnet-ef globalmente. Usa el siguiente comando:

bash
Copy
dotnet tool install --global dotnet-ef
Configuración
1. Configurar AutoMapper
En el archivo Program.cs, agrega lo siguiente para registrar AutoMapper:

csharp
Copy
builder.Services.AddAutoMapper(typeof(MappingProfile));
Este código configura AutoMapper para que utilice el perfil definido en la clase MappingProfile, donde defines cómo se debe mapear entre tus entidades y DTOs.

2. Configurar Entity Framework
En el archivo Program.cs o Startup.cs (dependiendo de tu versión de .NET):

csharp
Copy
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));
Asegúrate de definir la cadena de conexión en tu archivo appsettings.json:

json
Copy
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost;Database=ProductoDb;Trusted_Connection=True;"
  }
}
Ejecución
1. Compila y ejecuta la API
Para ejecutar la aplicación, simplemente usa el siguiente comando en la terminal de la raíz del proyecto:

bash
Copy
dotnet run
2. Accede a la API
Una vez que la aplicación esté en ejecución, puedes acceder a la API en la URL:

bash
Copy
http://localhost:5288/api/productos
Si tienes configurado Swagger, puedes acceder a la documentación de la API en:

bash
Copy
http://localhost:5288/swagger
Migraciones de la base de datos
Si necesitas generar las migraciones de Entity Framework Core, puedes usar los siguientes comandos.

1. Agregar migración
bash
Copy
dotnet ef migrations add NombreDeLaMigracion

2. Aplicar migraciones
bash
Copy
dotnet ef database update

Pruebas Unitarias
Si tienes pruebas unitarias configuradas en el proyecto, puedes ejecutarlas con el siguiente comando:

bash
Copy
dotnet test
