using AutoMapper;
using Producto.Models;

namespace Producto.Mapping
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            // Mapeo entre la entidad Producto y su DTO
            CreateMap<Productos, ProductoDto>().ReverseMap();

            // Mapeo entre la entidad ImagenProducto y su DTO
            CreateMap<ImagenProducto, ImagenProductoDto>().ReverseMap();
        }
    }
}
