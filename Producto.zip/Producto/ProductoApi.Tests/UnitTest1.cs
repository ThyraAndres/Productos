namespace ProductoApi.Tests;
using Xunit; // Asegúrate de que esta directiva esté presente

public class UnitTest1
{
    [Fact]
    public void Test1()
    {

    }
}